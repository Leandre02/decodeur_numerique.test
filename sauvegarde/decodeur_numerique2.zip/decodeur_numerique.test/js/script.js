/* Code JavaScript pour ma page principale */

    // Alerte de confirmation après l'envoi du formulaire
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Merci pour votre message !");
    });
  