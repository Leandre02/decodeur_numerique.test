<?php
/* Page pour mon api interactive qui malheureusement est a venir
* Pour le moment renvoie a ma page a-venir.php */

// Redirection vers la page a-venir.php
header('Location: a-venir.php');
exit;
?>
