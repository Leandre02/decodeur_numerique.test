<!-- Sous-section reservée pour la catégorie des enseignants-->

<?php

// Redirection vers la page a-venir.php
header('Location: a-venir.php');
exit;
?>
