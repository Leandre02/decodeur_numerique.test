<?php
/**
 * Page a venir pour mon site.
 * @author Léandre Kanmegne <2201877@carrefour.cegepvicto.ca>
 */
      
      require "include/configuration.inc";
?>

<head>
        <title>404 Error</title>
      <style>
             body {
            width: 60em;
         }
    </style>
</head>
<body>
        <br />
        <br />
<center>
    <h1>Not Found - 404</h1>
    <p>Page à venir. Revenez nous voir prochainement!</p>

</center>

        <br />
        <br />
        <br />
        <br />

<!-- Footer -->
                    <?php
                            require "include/nettoyage.inc";
                        ?>
</body>
</html>
