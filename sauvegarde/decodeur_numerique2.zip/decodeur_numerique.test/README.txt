https://ijnet.org/fr/story/ces-jeux-d%E2%80%99information-promeuvent-l%C3%A9ducation-aux-m%C3%A9dias-chez-les-jeunes

 Inspiration : https://www.fpjq.org/fr/repertoire-des-medias
 * https://fr.wikipedia.org/wiki/Liste_de_journaux_au_Canada