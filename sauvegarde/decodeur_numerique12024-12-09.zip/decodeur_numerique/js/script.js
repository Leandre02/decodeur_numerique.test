document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.getElementById("contactForm");
    const startQuizButton = document.getElementById("startQuiz");
  
    // Alerte de confirmation après l'envoi du formulaire
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Merci pour votre message !");
    });
  
    // Alerte avant le début du quiz
    startQuizButton.addEventListener("click", () => {
      alert("Le quiz interactif commencera bientôt !");
    });
  });
  